@extends('frontend/layouts.app')

@section('title', $pageinfo->metatitle)
@section('description', $pageinfo->metadescription)
@section('keywords', $pageinfo->metakeyword)

@section('content')

@endsection

