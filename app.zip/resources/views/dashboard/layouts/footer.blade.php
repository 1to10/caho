<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
        <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
        <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>

</aside>
<!-- /.control-sidebar -->
<!-- Add the sidebar's background. This div must be placed
     immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>


<footer class="main-footer">
    <div class="pull-right hidden-xs">
       <strong>&nbsp;</strong>
    </div>
    <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="https://www.interactivebees.com">Interactive Bees Pvt Ltd</a>.</strong> All rights
    reserved.
</footer>